package controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

public HelloController() {
System.out.println("Hello controller created....");
}
	
@RequestMapping("/hello")	
public @ResponseBody String hello(){
	return "Helo World!!!";
}	
	
@RequestMapping("/today")	
public @ResponseBody String today(){
	return "Today is "+new Date();
}	

}
