package com.atossyntel.ems.rest.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;

@RequestMapping("/employees")
@RestController
public class EmsRestController {

@Autowired
@Qualifier("esri")
private EmployeeService employeeService;  //dependenecy

public EmsRestController() {
System.out.println("EmsRest Controller  Created.....");
}


@GetMapping
public   List<Employee> getAllEmployees(){
	System.out.println("EmsRest Controller  getallemployees....");
	return employeeService.findAllEmployees();
}

@GetMapping("/filter")
public   List<Employee> getAllEmployeesWithSalaryBetween(@RequestParam("min")  double min,@RequestParam("max") double max){
	System.out.println("EmsRest Controller  getallemployeesWithSalaryBetween....min :"+min+" ,  max "+max);
	return employeeService.findAllEmployees()
			              .stream()
	                      .filter(e->e.getSalary()>=min && e.getSalary()<=max)
	                      .collect(Collectors.toList());
 
}



@GetMapping("/{employeeId}")
public   Employee getEmployeeById(@PathVariable("employeeId") int employeeId){
	System.out.println("EmsRest Controller  getemployeebyid ...."+employeeId);
	return employeeService.findEmployee(employeeId);
}

@DeleteMapping("/{employeeId}")
public   List<Employee> deleteEmployeeById(@PathVariable("employeeId") int employeeId){
	System.out.println("EmsRest Controller  deleteemployeebyid ...."+employeeId);
     employeeService.deleteEmployee(employeeId);
 	return employeeService.findAllEmployees();
}

@PutMapping("/{employeeId}")
public   List<Employee> updateEmployeeById(@PathVariable("employeeId") int employeeId,@RequestBody Employee employee){
	System.out.println("EmsRest Controller  updateemployeebyid ...."+employeeId);
     employeeService.updateEmployee(employee);
 	return employeeService.findAllEmployees();
}

@PostMapping
public   List<Employee> addEmployee(@RequestBody Employee employee){
	System.out.println("EmsRest Controller  addEmployee...."+employee);
     employeeService.saveEmployee(employee);
 	return employeeService.findAllEmployees();
}






}
