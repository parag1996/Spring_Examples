package com.atossyntel.ems.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;

@RequestMapping("/semployees")
@Controller
public class EmsSpringController {

@Autowired
@Qualifier("employeeServiceImpl")
private EmployeeService employeeService;  //dependenecy

public EmsSpringController() {
System.out.println("EmsSpringController  Created.....");
}


@RequestMapping("/hello1")
public String hello(){
System.out.println("In EmsSpring hello method...");
	return "hello";
}



@RequestMapping(method=RequestMethod.GET)
public ModelAndView getAllEmployees(){
System.out.println("############ In EmsSpring getallemployees.  ##############");
	return new ModelAndView("employeeList", "employees", employeeService.findAllEmployees());
}

@RequestMapping("/delete")
public ModelAndView deleteEmployee(@RequestParam("employeeId") int employeeId){

	System.out.println("In EmsSpring deleteemployeeId..."+employeeId);
    employeeService.deleteEmployee(employeeId);
	return new ModelAndView("employeeList", "employees", employeeService.findAllEmployees());
}

@RequestMapping("/edit/{employeeId}")
public String editEmployee(@PathVariable("employeeId") int employeeId,ModelMap map){
	map.addAttribute("employee",employeeService.findEmployee(employeeId));
	map.addAttribute("employees",employeeService.findAllEmployees());
	System.out.println("In EmsSpring editemployee..."+employeeId);
	return "editEmployee";
}

@RequestMapping("/new")
public String newEmployee(ModelMap map){
	map.addAttribute("employee",new Employee());
	map.addAttribute("employees",employeeService.findAllEmployees());
	System.out.println("In EmsSpring new Employee...");
		return "addEmployee";}




@RequestMapping(value="/update",method=RequestMethod.POST)
public ModelAndView saveEmployee( @ModelAttribute("employee") Employee employee){
	employeeService.updateEmployee(employee);
	
	System.out.println("In EmsSpring savEmployee..."+employee);
	return new ModelAndView("employeeList", "employees", employeeService.findAllEmployees());
}

@RequestMapping(value="/add",method=RequestMethod.POST)
public ModelAndView addEmployee( @ModelAttribute("employee") Employee employee){
	employeeService.saveEmployee(employee);
	System.out.println("In EmsSpring savEmployee..."+employee);
	return new ModelAndView("employeeList", "employees", employeeService.findAllEmployees());
}



}











